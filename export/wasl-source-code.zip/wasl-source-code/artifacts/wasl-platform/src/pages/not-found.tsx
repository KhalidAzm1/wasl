import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4 text-foreground">
      <Card className="w-full max-w-md mx-4 glass-card border-foreground/10">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <h1 className="text-2xl font-bold">404 - Page Not Found</h1>
          </div>
          <p className="mt-4 text-sm text-foreground/60 text-left">
            Sorry, the page you're looking for doesn't exist.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
